package pt.gestaocontatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoContatosApplication {

    public static void main(String[] args) {
        SpringApplication.run(GestaoContatosApplication.class, args);
    }
}